package pepse.world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.RectangleRenderable;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import pepse.util.ColorSupplier;

import java.awt.*;

import static java.lang.Math.abs;

public class Terrain {

    private static final Color BASE_GROUND_COLOR = new Color(212, 123, 74);
    private static final int TERRAIN_DEPTH = 20;
    private GameObjectCollection gameObjects;
    private int groundLayer;
    private final float groundHeightAtX0;
    private Vector2 windowDimensions;
    private NoiseGenerator noisegen;

    public Terrain(GameObjectCollection gameObjects, int groundLayer, Vector2 windowDimensions, int seed) {
        this.gameObjects = gameObjects;
        this.groundLayer = groundLayer;
        this.groundHeightAtX0 = (float) 2 / 3 * windowDimensions.y();
        this.windowDimensions = windowDimensions;
        noisegen = new NoiseGenerator(seed);
    }

    public float groundHeightAt(float x) { //TODO - not changing with x - do sinus
        return  groundHeightAtX0 + (float)abs(noisegen.noise(x / 35))*groundHeightAtX0;

    }

    public void createInRange(int minX, int maxX) { // TODO implement - perlin noise
        float ground_level;
        minX = (int) (Math.floor(minX/ Block.SIZE) * Block.SIZE);
        maxX = (int) (Math.ceil((float) maxX/ Block.SIZE) * Block.SIZE);
        float maxY = (float) (Math.ceil(windowDimensions.y()/ Block.SIZE) * Block.SIZE);
        for (int i = minX; i <= maxX; i += Block.SIZE) {
            ground_level = (float) (Math.floor(groundHeightAt(i) / Block.SIZE) * Block.SIZE);
            for (float j = ground_level; j <= maxY; j += Block.SIZE) {
                GameObject block = new Block(new Vector2(i,j), new Vector2(Block.SIZE, Block.SIZE),
                        new RectangleRenderable(ColorSupplier.approximateColor(BASE_GROUND_COLOR)));
                if(j == ground_level){
                    gameObjects.addGameObject(block, Layer.DEFAULT);
                }
                else{
                    gameObjects.addGameObject(block, Layer.DEFAULT + 1);
                }
                block.setTag("block");
            }
        }

    }


}
